import SwiftUI
import Charts

struct XYLabel {
  var x: String
  var y: Double
}

struct CustomLineChartView: UIViewControllerRepresentable {
  @Binding var data: [XYLabel]

  func makeUIViewController(context: Context) -> OneVC {
    print("[data]", data)
    return OneVC(data: data)
  }
  
  func updateUIViewController(_ uiViewController: OneVC, context: Context) {
    
  }
}

class OneVC: UIViewController {
  @State var data: [XYLabel]
  private var chartView: LineChartView!
  
  init(data: [XYLabel]) {
    self.data = data
    super.init(nibName: nil, bundle: nil)
  }
  
  required init?(coder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
  
  override func viewDidLoad() {
    super.viewDidLoad()
    self.view.backgroundColor = UIColor.white
    
    chartView = LineChartView()

    chartView.frame = CGRect(
      x: 10, y: 80,
      width: view.bounds.width - 60, height: 250
    )
    self.view.addSubview(chartView)
    
    // 数据源
    var dataEntries = [ChartDataEntry]()
    var xLabel: [Double] = []
    for i in data {
      var x: Double
      if i.x.contains("-") {
        x = Double(i.x.replacingOccurrences(of: "-", with: "")) ?? 0
      } else {
        x = Double(i.x) ?? 0
      }
      xLabel.append(x)
      let entry = ChartDataEntry.init(x: x, y: i.y)
      dataEntries.append(entry)
    }
    print("【数据】", xLabel)

    // Every ChartDataSet as a data source of Chart.
    let chartDataSet = LineChartDataSet(entries: dataEntries, label: "")
    chartDataSet.drawCirclesEnabled = true
    chartDataSet.drawValuesEnabled = false // 点值
    // chartDataSet.highlightEnabled = false
    chartDataSet.colors = [.orange]

    let chartData = LineChartData(dataSets: [chartDataSet])

    chartView.leftAxis.drawZeroLineEnabled = true
    chartView.data = chartData
    chartView.borderColor = .black
    chartView.borderLineWidth = 1
    chartView.drawGridBackgroundEnabled = false
    chartView.noDataText = "暂无数据"
    chartView.legend.textColor = UIColor.gray
    chartView.legend.form = .none

//    chartView.xAxis.entries = xLabel
    chartView.xAxis.labelPosition = .bottom
    chartView.xAxis.drawGridLinesEnabled = false
    chartView.xAxis.labelTextColor = .gray
    chartView.xAxis.granularity = 1
    chartView.xAxis.drawAxisLineEnabled = false
//    chartView.xAxis.labelCount = xLabel.count
//    chartView.xAxis.axisMaxLabels = xLabel.count
    chartView.rightAxis.drawLabelsEnabled = false
    chartView.rightAxis.enabled = false
    chartView.animate(xAxisDuration: 1, yAxisDuration: 1)

    chartView.xAxis.valueFormatter = IndexAxisValueFormatter(values: xLabel.map { String($0) }) // 横坐标置空
  }
}

