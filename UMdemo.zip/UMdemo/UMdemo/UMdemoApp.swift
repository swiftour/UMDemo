//
//  UMdemoApp.swift
//  UMdemo
//
//  Created by fdsure-song on 2023/7/27.
//

import SwiftUI

@main
struct UMdemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
