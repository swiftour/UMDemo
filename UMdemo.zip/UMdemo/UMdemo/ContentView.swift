//
//  ContentView.swift
//  UMdemo
//
//  Created by fdsure-song on 2023/7/27.
//

import SwiftUI

struct ContentView: View {
  @State var show = false
  @State var chartData: [XYLabel] = [
    XYLabel(x: "20230706", y: 2012131),
    XYLabel(x: "20230709", y: 2012123)
  ]

    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundColor(.accentColor)
            Text("Hello, world!")
          Button {
            show = true
          } label: {
            Text("点击")
          }
          
          CustomLineChartView(data: $chartData).offset(y: -70)

        }
        .padding()
        .sheet(isPresented: $show) {
          Text("1111")
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
